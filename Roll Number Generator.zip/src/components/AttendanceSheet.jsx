import React, { useState } from "react";
import { useSheetContext } from "../context/sheetData";
import logo from "../assets/khyber_medical_university_logo.jpeg";
import ihslogo from "../assets/kmu_ihs_logo.png";

function AttendanceSheet({ selectedAtStatus }) {
  const { excelData, editableData } = useSheetContext();

  // Define students per page
  const studentsPerPage = 25;

  // Get the full list of students from excelData
  const allStudents = excelData[0]?.data || [];

  // Get all unique subjects from all students - FIXED
  const getAllUniqueSubjects = () => {
    if (!excelData[0]?.data) return [];

    const allSubjects = new Set();
    excelData[0].data.forEach((student) => {
      student.subjects?.forEach((subject) => {
        if (
          typeof subject === "object" &&
          subject.subject &&
          subject.subject.trim() !== ""
        ) {
          allSubjects.add(subject.subject.trim());
        } else if (typeof subject === "string" && subject.trim() !== "") {
          // Handle case where subject might still be a string
          allSubjects.add(subject.trim());
        }
      });
    });

    return Array.from(allSubjects);
  };

  const uniqueSubjects = getAllUniqueSubjects();

  // Function to chunk the array into smaller arrays of `chunkSize`
  const chunkArray = (arr, chunkSize) => {
    const chunks = [];
    for (let i = 0; i < arr.length; i += chunkSize) {
      chunks.push(arr.slice(i, i + chunkSize));
    }
    return chunks;
  };

  // ✅ Count regular and re-appear students
  const regularStudents =
    excelData[0]?.data.filter(
      (s) => s.status?.toLowerCase().trim() === "regular"
    ) || [];

  const reappearStudents =
    excelData[0]?.data.filter(
      (s) => s.status?.toLowerCase().trim() === "re-appear"
    ) || [];

  const regularStudentsCount = regularStudents.length;

  // Function to check if student has a specific subject - FIXED
  const studentHasSubject = (student, subjectName) => {
    return student.subjects?.some((subject) => {
      if (typeof subject === "object") {
        return subject.subject === subjectName;
      } else if (typeof subject === "string") {
        return subject === subjectName;
      }
      return false;
    });
  };

  // Function to get subject date - FIXED
  const getSubjectDate = (subjectName) => {
    // First try to find in editableData.subjects
    const editableSubject = editableData.subjects?.find(
      (sub) =>
        sub.subject.toLowerCase().trim() === subjectName.toLowerCase().trim()
    );

    if (editableSubject?.date && editableSubject.date !== "dd/mm/yyyy") {
      return editableSubject.date;
    }

    // If not found in editableData, try to find in any student's subjects
    for (let student of allStudents) {
      const studentSubject = student.subjects?.find((sub) => {
        if (typeof sub === "object") {
          return sub.subject === subjectName;
        }
        return false;
      });
      if (studentSubject?.date && studentSubject.date !== "dd/mm/yyyy") {
        return studentSubject.date;
      }
    }

    return "dd/mm/yyyy"; // Default date
  };

  return (
    <>
      {/* Generate separate sheets for each subject */}
      {uniqueSubjects.map((subject, subjectIndex) => {
        // Filter students who have this subject - FIXED
        const studentsWithSubject = allStudents.filter((student) =>
          studentHasSubject(student, subject)
        );

        // Create chunks of students for this subject
        const studentChunks = chunkArray(studentsWithSubject, studentsPerPage);

        return (
          <React.Fragment key={subjectIndex}>
            {studentChunks.map((chunk, chunkIndex) => (
              // Each chunk will render a full attendance sheet container for this subject
              <div
                className="attendanceSheetContainer p-4 mb-5"
                key={`${subjectIndex}-${chunkIndex}`}
              >
                {chunkIndex === 0 && (
                  <>
                    <div className="headerSection d-flex justify-content-between align-items-center mb-4">
                      <div className="ihsLogoWrapper">
                        <img src={logo} alt="KMU" className="kmuLogo" />
                        {editableData.logoImagePath && (
                          <img
                            src={editableData.logoImagePath}
                            alt="ihs logo"
                            className="ihsLogo  "
                          />
                        )}
                      </div>
                      <div className="titleSection">
                        <h1 className="universityTitle">
                          Khyber Medical University
                        </h1>
                        <p className="programTitle">
                          Regional - {excelData[0]?.regionalExamCell}
                        </p>
                        <p className="bsnText mb-0">
                          {editableData.semesterTitle}
                        </p>
                        <p className="semesterTitle">ATTENDANCE SHEET</p>
                        {selectedAtStatus === "Circuit" && (
                          <p className="semesterTitle">
                            Computer Base Examination
                          </p>
                        )}
                      </div>
                      <div
                        className="emptySpace"
                        style={{ width: "100px" }}
                      ></div>{" "}
                    </div>
                    <div className="courseDetails mb-4">
                      <p className="detailRow mb-1">
                        <span
                          className="detailLabel"
                          style={{ minWidth: "auto" }}
                        >
                          Exam Centre :
                        </span>
                        <span className="detailValue ms-2">
                          {editableData.examCenter}
                        </span>
                      </p>
                      <p className="detailRow mb-1">
                        <span
                          className="detailLabel"
                          style={{ minWidth: "auto" }}
                        >
                          Institute :
                        </span>
                        <span className="detailValue ms-2">
                          {excelData[0]?.instituteName || ""}
                        </span>
                      </p>
                      <div className="d-flex align-items-center gap-4 justify-content-between">
                        <p className="detailRow  mb-1">
                          <span
                            className="detailLabel"
                            style={{ minWidth: "auto" }}
                          >
                            Subject :
                          </span>
                          <span className="detailValue">{subject}</span>
                        </p>

                        <p className="detailRow  mb-1">
                          <span
                            className="detailLabel"
                            style={{ minWidth: "auto" }}
                          >
                            Date :
                          </span>
                          <span
                            className="detailValue ms-2 "
                            style={{ width: "100px" }}
                          >
                            {getSubjectDate(subject)}
                          </span>
                        </p>
                      </div>
                    </div>
                  </>
                )}

                {/* Attendance Table - Specific to each chunk and subject */}
                <div className="tableResponsive mb-4">
                  <table className="attendanceTable table table-bordered">
                    <thead className="tableHeader">
                      <tr>
                        <th className="tableHeaderCell" rowSpan="2">
                          S.No:
                        </th>
                        <th className="tableHeaderCell" rowSpan="2">
                          Roll No
                        </th>
                        <th className="tableHeaderCell" rowSpan="2">
                          Student Name
                        </th>
                        <th className="tableHeaderCell" rowSpan="2">
                          Father Name
                        </th>
                        <th className="tableHeaderCell">
                          {selectedAtStatus ? selectedAtStatus : " Paper Code"}
                        </th>
                        <th className="tableHeaderCell">Signature</th>
                      </tr>
                    </thead>
                    <tbody className="tableBody">
                      {chunk.map((student, index) => {
                        const globalIndex =
                          chunkIndex * studentsPerPage + index;
                        const baseRoll = parseInt(editableData.rollNumber);
                        const status = student.status?.toLowerCase().trim();

                        let rollNum;

                        if (status === "regular") {
                          // find this student's position among regular students
                          const regularIndex = regularStudents.findIndex(
                            (s) => s.rollNumber === student.rollNumber
                          );

                          // ✅ start from base roll + regularIndex
                          rollNum = baseRoll + regularIndex + globalIndex;
                        } else if (status === "re-appear") {
                          // find this student's position among reappear students
                          const reappearIndex =
                            reappearStudents.indexOf(student);

                          if (regularStudentsCount > 0) {
                            // 🟩 there are regular students → start after 20-number gap
                            const lastRegularRoll =
                              baseRoll + regularStudentsCount - 1;
                            rollNum = lastRegularRoll + 20 + reappearIndex;
                          } else {
                            // 🟦 only reappear students → start right after base roll
                            rollNum = baseRoll + reappearIndex;
                          }
                        } else {
                          rollNum = baseRoll;
                        }

                        return (
                          <tr key={globalIndex} className="tableRow">
                            <td className="tableCell">{globalIndex + 1}</td>
                            <td className="tableCell">
                              {String(rollNum).padStart(7, "0")}
                              &nbsp; {status === "re-appear" && "(RA)"}
                            </td>
                            <td className="tableCell">{student.name}</td>
                            <td className="tableCell">{student.fatherName}</td>
                            <td className="tableCell"></td>
                            <td className="tableCell"></td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {/* Show page info if multiple chunks */}
                {studentChunks.length > 1 && (
                  <div className="pageInfo text-center mt-3">
                    Page {chunkIndex + 1} of {studentChunks.length}
                  </div>
                )}

                {/* Footer Section - Repeated for each sheet */}
                <div className="footerSection d-flex justify-content-between align-items-end mt-5">
                  <div className="signatureBlock">
                    <p className="signatureLabel mb-0">Signature of Supdt :</p>
                    <div className="signatureLine"></div>
                  </div>
                  <div className="signatureBlock text-end">
                    <p className="signatureLabel mb-0">Deputy Supdt :</p>
                    <div className="signatureLine ms-auto"></div>
                  </div>
                </div>

                <div className="  d-flex justify-content-between align-items-end mt-5">
                  <div className="signatureBlock">
                    <p className="signatureLabel mb-0">Total Students :</p>
                    <div className="signatureLine"></div>
                  </div>
                  <div className="signatureBlock ">
                    <p className="signatureLabel mb-0">Present Students :</p>
                    <div className="signatureLine"></div>
                  </div>
                  <div className="signatureBlock text-end">
                    <p className="signatureLabel mb-0">Absent Students :</p>
                    <div className="signatureLine ms-auto"></div>
                  </div>
                </div>

                <br />
                <br />
                <br />
                <br />
              </div>
            ))}
          </React.Fragment>
        );
      })}

      {/* Custom CSS */}
      <style>{`
        .attendanceSheetContainer {
          max-width: 1100px;
          margin: 20px auto;
          border: 1px solid #ccc;
          padding: 30px;
          box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
          background-color: #fff;
          border-radius: 8px;
          padding-bottom: 3rem;
        }
 
        .tableHeaderCell {
          vertical-align: middle;
          text-align: center;
          font-weight: bold;
          border: 1px solid #000 !important; /* Ensure borders are black */
          padding: 8px;
        }

        .tableBody .tableRow:nth-child(even) {
          background-color: #f2f2f2; /* Light grey for even rows */
        }

        .tableCell {
          border: 1px solid #000 !important; /* Ensure borders are black */
          padding: 8px;
          text-align: left;
          vertical-align: middle;
        }

        .signatureCell {
          min-width: 150px; /* Provide space for signatures */
          text-align: left;
        }

        .footerSection {
          padding-top: 20px; 
        }

        .signatureBlock {
          flex: 1;
          padding: 0 20px;
        }

        .signatureLabel {
          font-weight: bold;
          font-size: 1.1rem;
        } 
        .signatureLine {
          border-bottom: 1px solid #000;
          margin-top: 30px; /* Space for signature */
          width: 80%; /* Adjust line length */
        }
      `}</style>
    </>
  );
}

export default AttendanceSheet;
