import { useEffect, useState, useRef } from "react";
import { useSheetContext } from "../context/sheetData";
import { FiPlusCircle, FiTrash2, FiUpload } from "react-icons/fi";
import { FaPlus } from "react-icons/fa";
import logo from "../assets/khyber_medical_university_logo.jpeg";
import ihslogo from "../assets/kmu_ihs_logo.png";
import signature from "../assets/signature.png";
import { enqueueSnackbar } from "notistack";
import { useNavigate } from "react-router-dom";

const DefaultSlip = ({
  setRollNumLength,
  setRollNumberFocus,
  rollNumberFocus,
  rollNumLength,
  setFileUploaded,
}) => {
  const { excelData, editableData, setEditableData } = useSheetContext();
  const [hoveredRow, setHoveredRow] = useState(null);
  const [isLogoHovered, setIsLogoHovered] = useState(false);
  const fileInputRef = useRef(null);

  const navigate = useNavigate();

  // Get all unique subjects from all students
  const getAllUniqueSubjects = () => {
    if (!excelData[0]?.data) return [];

    const allSubjects = new Set();
    excelData[0].data.forEach((student) => {
      student.subjects?.forEach((subject) => {
        if (subject && subject.trim() !== "") {
          allSubjects.add(subject.trim());
        }
      });
    });

    return Array.from(allSubjects);
  };

  const uniqueSubjects = getAllUniqueSubjects();

  const handleInputChange = (e, key, index) => {
    if (key === "subjects") {
      const updatedSubjects = [...editableData.subjects];
      updatedSubjects[index][e.target.name] = e.target.value;
      setEditableData({ ...editableData, subjects: updatedSubjects });
    } else {
      setEditableData({ ...editableData, [key]: e.target.value });
    }
  };

  // Handle subject date/time change for unique subjects
  const handleUniqueSubjectChange = (subjectName, field, value) => {
    // Find if this subject already exists in editableData.subjects
    const existingSubjectIndex = editableData.subjects.findIndex(
      (sub) =>
        sub.subject.toLowerCase().trim() === subjectName.toLowerCase().trim()
    );

    if (existingSubjectIndex !== -1) {
      // Update existing subject
      const updatedSubjects = [...editableData.subjects];
      updatedSubjects[existingSubjectIndex][field] = value;
      setEditableData({ ...editableData, subjects: updatedSubjects });
    } else {
      // Create new subject entry
      const newSubject = {
        id: `unique-${subjectName}`,
        subject: subjectName,
        date: field === "date" ? value : "6-Jan-25",
        timing: field === "timing" ? value : "9:30 am to 12:30 pm",
      };
      const updatedSubjects = [...editableData.subjects, newSubject];
      setEditableData({ ...editableData, subjects: updatedSubjects });
    }
  };

  const addNewRow = () => {
    const newRow = {
      id: editableData.subjects.length + 1,
      subject: "Subject-||",
      date: "3-Jan-25",
      timing: "9:30 am to 12:30 pm",
    };
    const updated = [...editableData.subjects, newRow];
    setEditableData({ ...editableData, subjects: updated });
  };

  const deleteRow = (index) => {
    const updated = [...editableData.subjects];
    updated.splice(index, 1);
    setEditableData({ ...editableData, subjects: updated });
  };

  // Handle logo upload
  const handleLogoUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageUrl = e.target.result;
        setEditableData({
          ...editableData,
          logoImagePath: imageUrl,
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const handleGenerateRollNumbers = () => {
    const currentRollNumLength = String(rollNumLength).length;
    if (currentRollNumLength < 7) {
      enqueueSnackbar("Roll Number should be exactly 7 characters.");
      setRollNumberFocus(true);
      return;
    }
    navigate("/rollNumbers");
  };

  console.log("this is data ", excelData);

  useEffect(() => {
    setRollNumLength(editableData.rollNumber);
  }, [editableData.rollNumber]);

  return (
    <>
      <div className="admitCardContainer">
        <div className="mainBorder">
          {/* Header Section */}

          <div className="headerSection">
            <div className="ihsLogoWrapper">
              <img src={logo} alt="KMU" className="kmuLogo" />

              {/* IHS Logo with upload functionality */}
              <div
                className="ihsLogoContainer"
                onMouseEnter={() => setIsLogoHovered(true)}
                onMouseLeave={() => setIsLogoHovered(false)}
                style={{ position: "relative", display: "inline-block" }}
              >
                <img
                  src={editableData.logoImagePath || ihslogo}
                  alt="ihs logo"
                  className="ihsLogo mt-2"
                />

                {/* Upload overlay */}
                {isLogoHovered && (
                  <div
                    className="logoUploadOverlay"
                    style={{
                      position: "absolute",
                      top: 0,
                      left: 0,
                      right: 0,
                      bottom: 0,
                      backgroundColor: "rgba(0, 0, 0, 0.5)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      borderRadius: "4px",
                      cursor: "pointer",
                    }}
                    onClick={triggerFileInput}
                  >
                    <FiUpload
                      style={{
                        color: "white",
                        fontSize: "24px",
                        filter: "drop-shadow(0 0 2px rgba(0,0,0,0.5))",
                      }}
                    />
                  </div>
                )}

                {/* Hidden file input */}
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleLogoUpload}
                  accept="image/*"
                  style={{ display: "none" }}
                />
              </div>
            </div>

            <div className="titleSection">
              <h1 className="universityTitle">Khyber Medical University</h1>
              <p className="programTitle">
                Regional Exam Cell - {excelData[0]?.regionalExamCell}
              </p>
              <input
                type="text"
                className="semesterTitle"
                value={editableData.semesterTitle}
                style={{ width: "100%", textAlign: "center" }}
                onChange={(e) => handleInputChange(e, "semesterTitle")}
              />
              <p className="studentCopyText">[Student Copy]</p>
            </div>

            <div className="noticeBox">
              <p className="noticeText">Cell Phone, Smart Watch</p>
              <p className="noticeText">or any Electronic Gadgets</p>
              <p className="noticeText">are not allowed</p>
            </div>
          </div>

          {/* Student Information */}
          <div className="studentInfoSection mt-5">
            <div className="studentDetails">
              <div className="infoRow">
                <div className="infoItem" style={{ flex: 1 }}>
                  <span className="infoLabel">Name:</span>
                  <input
                    type="text"
                    className="infoValue"
                    value={editableData.name}
                    disabled
                    onChange={(e) => handleInputChange(e, "name")}
                  />
                </div>
                <div className="infoItem" style={{ flex: 1 }}>
                  <span className="infoLabel">Father Name:</span>
                  <input
                    type="text"
                    className="infoValue"
                    disabled
                    value={editableData.fatherName}
                    onChange={(e) => handleInputChange(e, "fatherName")}
                  />
                </div>
                <div className="infoItem">
                  <span className="infoLabel">Roll No:</span>
                  <input
                    type="number"
                    className={`infoValue ${rollNumberFocus && "inputFocus"}`}
                    value={editableData.rollNumber}
                    onChange={(e) => {
                      let value = e.target.value;
                      if (value.length >= 7) {
                        value = value.slice(0, 7);
                        setRollNumberFocus(false);
                      } else {
                        setRollNumberFocus(true);
                      }
                      handleInputChange(
                        { target: { value: value } },
                        "rollNumber"
                      );
                    }}
                    maxLength={7}
                  />
                </div>
              </div>

              <div className="row">
                <div className="col-9">
                  <div className="infoRow">
                    <div className=" mt-1 w-100">
                      <div className="infoItem">
                        <span className="infoLabel">Registration No:</span>
                        <input
                          type="text"
                          className="infoValue"
                          disabled
                          value={editableData.registrationNo}
                          onChange={(e) =>
                            handleInputChange(e, "registrationNo")
                          }
                        />
                      </div>
                      <div className="infoItem mt-2" style={{ flex: 1 }}>
                        <span className="infoLabel">Institute:</span>
                        <span className="infoValue">
                          {excelData[0]?.instituteName || ""}
                        </span>
                        {/* <input
                          type="text"
                          className=""
                          disabled
                          value=
                          onChange={(e) => handleInputChange(e, "institute")}
                        /> */}
                      </div>
                    </div>
                  </div>

                  {/* Examination Schedule Table */}
                  <div className="examTableWrapper mt-3 w-100">
                    <table className="examTable ">
                      <colgroup>
                        <col width={"5%"} />
                        <col width={"45%"} />
                        <col width={"20%"} />
                        <col width={"30%"} />
                      </colgroup>
                      <thead>
                        <tr className="  tableHeader ">
                          <th className="tableHeaderCell">S.No</th>
                          <th className="tableHeaderCell">Subject</th>
                          <th className="tableHeaderCell">Date</th>
                          <th className="tableHeaderCell">Timing</th>
                        </tr>
                      </thead>
                      <tbody>
                        {/* Display unique subjects only once */}
                        {uniqueSubjects.map((subject, index) => {
                          const editableSubject = editableData.subjects.find(
                            (editableSub) =>
                              editableSub.subject.toLowerCase().trim() ===
                              subject.toLowerCase().trim()
                          );

                          return (
                            <tr key={index} className="tableRow">
                              <td
                                className="tableCell"
                                style={{ width: "40px" }}
                              >
                                {index + 1}
                              </td>
                              <td className="tableCell text-start">
                                {subject}
                              </td>
                              <td className="tableCell">
                                <input
                                  type="text"
                                  name="date"
                                  value={editableSubject?.date || "6-Jan-25"}
                                  className="tableCellInput"
                                  onChange={(e) =>
                                    handleUniqueSubjectChange(
                                      subject,
                                      "date",
                                      e.target.value
                                    )
                                  }
                                />
                              </td>
                              <td className="tableCell deleteRowCell">
                                <input
                                  type="text"
                                  name="timing"
                                  value={
                                    editableSubject?.timing ||
                                    "9:30 am to 12:30 pm"
                                  }
                                  className="tableCellInput"
                                  onChange={(e) =>
                                    handleUniqueSubjectChange(
                                      subject,
                                      "timing",
                                      e.target.value
                                    )
                                  }
                                />
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>

                    <FaPlus
                      onClick={() => addNewRow()}
                      title="Add new row below"
                      className="addnewRowButton"
                    />
                  </div>

                  {/* Exam Center */}
                  <div className="examCenterSection w-100">
                    <span className="examCenterLabel">Exam Center: </span>
                    <input
                      type="text"
                      className="examCenterValue"
                      value={editableData.examCenter}
                      style={{ flex: 1 }}
                      onChange={(e) => handleInputChange(e, "examCenter")}
                    />
                  </div>
                </div>

                <div className="col-3">
                  <div className="photoContainer ms-auto">
                    <div className="photoPlaceholder text-center">
                      Student Photo
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-4 ms-auto">
                {/* Signature Section */}
                <div className="signatureSection text-center">
                  <div className="signatureSpace">
                    <img src={signature} alt="sign" className="signImage" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Instructions */}
          <div className="instructionsSection">
            <h3 className="instructionsTitle">INSTRUCTIONS :</h3>
            <div className="instructionsList">
              <p className="instructionItem">
                1. You are advised to report at exam centre thirty (30) minutes
                before the scheduled paper time.
              </p>

              <p className="instructionItem">
                2. You are advised to bring this ROLL NO SLIP along with your
                Original National ID Card / Passport or B-Form or Matric
                Certificate (less than 18 years age) containing your photograph
                (mandatory). Candidates failing to produce ROLL NO SLIP and
                Original CNIC would not be allowed to enter the examination
                hall.
              </p>

              <p className="instructionItem">
                3. If your CNIC/B Form is lost, please bring a copy of FIR,
                Newspaper cutting and Original NADRA token showing that you have
                applied for the same.
              </p>

              <p className="instructionItem">
                4. Please don't bring any of Gadgets with you. Candidates shall
                be searched for cellphones/smart/watch/electronic devices and if
                found, it will be confiscated and UFM case shall be registered
                accordingly.
              </p>

              <p className="instructionItem">
                5. No candidate will be allowed to enter the examination hall
                after 15 minutes of the start of paper.
              </p>
              <p className="instructionItem">
                6. Any student who fails to fill the paper code or Roll No on
                MCQ response sheet will be considered absent.
              </p>

              <p className="instructionItem">
                7. This Roll No is being issued provisionally and shall be
                confirmed subject to verification.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="mb-5 d-flex align-items-center justify-content-center gap-4">
        <button
          className=" downloadButton"
          onClick={() => setFileUploaded(false)}
          style={{
            padding: "0.6rem 1rem",
            textTransform: "uppercase",
            fontSize: "1rem",
            fontWeight: "600",
          }}
        >
          back to upload
        </button>
        <button
          className="generateButton"
          onClick={() => handleGenerateRollNumbers()}
        >
          Generate Roll Numbers
        </button>
      </div>
    </>
  );
};

export default DefaultSlip;
